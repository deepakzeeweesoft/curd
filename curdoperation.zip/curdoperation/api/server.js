var express = require('express');
var router = express.Router();
var mysql = require('mysql');
var cors = require('cors');
var multer  = require('multer')
var path=require('path')


var app = express();
app.use(cors({origin:"*"}))
app.use('/',router);


  
var bodyParser = require('body-parser')
//  app.use(bodyparser.json) 


 app.use(bodyParser.urlencoded({
    extended: true
}));

// parse application/json
app.use(bodyParser.json())

const storage=multer.diskStorage({
    destination:'.upload/images',
    filename:(req,file,cb)=>{
        return cb(null,`${file.fieldname}_${Date.now()}${path.extname(file.originalname)}`)
       
    }
   // filename: function (req, file, cb) { cb(null, file.fieldname + '_' + Date.now()) }
});
const imageUpload = multer({ storage: storage }).single('image');



app.listen(3000, () => {
    console.log('Express api is running on 3000');
})

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'samo123',
    database: 'product',
    // multipleStatements:true
});
// connection.connect();
connection.connect(function (err) {
    if (err) throw err;
    console.log("Database is Connected!");
});



const upload=multer({
    storage:storage
    //   dest:'.upload/images'
})/////



// app.get('/api/upload', (req, res) => {
//     res.json({
//         'message': 'hello'
//     });
// });
               
// app.post('/api/upload', multipartMiddleware, (req, res) => {
//     res.json({
//         'message': 'File uploaded successfully'
//     });
// });


app.get('/getproductList', (req, res,next) => {

    console.log("api is work")
    connection.query("SELECT * FROM product_list",  (err, data) => {
        if (!err) {
            console.log("data: ", data);
            //   result(null, err);
           // res.send(data)
            //   return;
            res.status(200).json(data)
        }
        else {
            console.log(err)
            // res.send(data)
        }
        console.log(data, 'data')
    })
})


app.get('/getproductList/:id', (req, res) => {
    console.log("api is work")
    connection.query("SELECT * FROM product_list WHERE id= ?", [req.params.id], (err, data) => {
        if (!err) {
            console.log("data: ", data);

            res.send(data)
        }
        else
            console.log(err)
    })
});


app.delete('/deleteproduct/:id', (req, res) => {
    console.log("api is work")
    connection.query("DELETE FROM `product_list` WHERE id= ?", [req.params.id], (err, data) => {
        if (!err) {
            console.log("Deleted Successfull !!!! ");

            res.send(data)
        }
        else
            console.log(err)
    })
})

app.use('/profile',express.static('upload/images'))
app.post('/Addproduct',upload.single('profile'), (req, res) => {
   // app.post('/Addproduct', (req, res) => {
    console.log("post api is work");
//    console.log(req.file);
    console.log(req.body);
              res.json({
                  success:1,
                profile_url:`http://localhost:3000/profile/${req.file.filename}`
              })

            //   if (req.file != undefined) {
            //     if (req.body.fieldname == "profile_img") fs.unlink(result[0].profile_img, (err => { }));
            // }


   // return
    sql = "INSERT INTO product_list SET ? ";
    
      connection.query(sql, [req.body] , (err,data)=>{
        if (!err) {
            
            res.send(data[0])
        }
        else
            console.log(err)
      })       
    })


// /vis
// app.post('/Addproduct',imageUpload, (req, res) => {
//     // app.post('/Addproduct', (req, res) => {
//      console.log("post api is work");
//  //    console.log(req.file);
//      console.log(req.body);
//                res.json({
//                    success:1,
//                  profile_url:`http://localhost:3000/profile/${req.file.filename}`
//                })
 
//                if (req.file != undefined) {
//                  if (req.body.fieldname == "profile_img") fs.unlink(result[0].profile_img, (err => { }));
//              }
 
 
//     // return
//      sql = "INSERT INTO product_list SET ? ";
     
//        connection.query(sql, [req.body] , (err,data)=>{
//          if (!err) {
             
//              res.send(data[0])
//          }
//          else
//              console.log(err)
//        })       
//      })
    

app.put('/Editproduct/:id', (req, res) => {
    console.log("put api is work")
    console.log("Req body and params id is:",req.body,req.params.id);
    sql = "UPDATE INTO product_list SET ? WHERE id=?";
    connection.query(sql,[req.body, req.params.id], (err, data) => {
        if (!err) {
            console.log("Updated Successfull !!!! ", data);

            res.send(data)
        }
        else
            console.log(err);
    })
})



