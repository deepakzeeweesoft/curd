import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ProductServiceService } from '../service/product-service.service'

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {
  [x: string]: any;
  uploadedFiles: Array < File > ;
  registerForm: FormGroup;
  submitted = false;
  products = [];
  id;
  image = null;
  allproduct: Object;
  item: any;
  add;
 // uploadedFiles

  constructor(private formBuilder: FormBuilder,
    private productServiceService: ProductServiceService,
    private router: Router) { }






  ngOnInit() {



    this.getLatestProduct()
    this.registerForm = this.formBuilder.group({
      image: ['',],
      Name: ['', Validators.required],
      model_no: ['', Validators.required],
      price: ['', Validators.required],
    //  acceptTerms: [false, Validators.requiredTrue]
    })

  }


  getLatestProduct() {
    this.productServiceService.getallproduct().subscribe((responce) => {
      this.allproduct = responce;
    })
  }



  addproduct() {
     console.log("=====add")
    console.log(this.registerForm.value, 'vaue')
    // this.productServiceService.createproduct(formdata).subscribe((responce)=>{
    //     this.getLatestProduct();
    // console.log(this.registerForm.value.Name)
      let data = this.registerForm.value
  //   let formdata = new FormData();
    // formdata.append('image',this.uploadedFiles[0]),
      // formdata.append('Name', this.registerForm.value.Name),
      // formdata.append('ModelNo', this.registerForm.value.ModelNo),
      // formdata.append('price', this.registerForm.value.price)

    // console.log("data is successfully append");
    // console.log("Form data is:",formdata);

        this.productServiceService.createproduct(data).subscribe((responce) => {
          console.log("Added resonce is:",responce)
      this.router.navigate(["/List"]);
      // this.add=responce;
       console.log('add==', responce)
      // this.allproduct
    },

      // this.productServiceService.get().subscribe((data: any[])=>{
      //   console.log(data);
      //   this.products = data;
      // })  

    )
  }



  // addproduct(formObj)
  // {
  //   console.log("Form obj is",formObj)
  //   this.productServiceService.createproduct(formObj).subscribe((responce)=>{
  //      console.log("product has been added");
  //     // this.router.navigate(["/advertisement/list"]);
  //      this.getLatestProduct();
  //   })
  // }



  get f() { return this.registerForm.controls; }
  onSubmit() {
    this.submitted = true;

    console.log(this.registerForm.value)
  
    if (this.registerForm.invalid) {
         console.log("Register form value is invalid");
      return;
    }
  }



  onReset() {
    this.submitted = false;
    this.registerForm.reset();
  }


//   fileChange(element) {
//     alert("File change is work")
//     this.uploadedFiles = element.target.files;
//     console.log("Uploded file is:",this.uploadedFiles)
// }

// upload() {
//   let formData = new FormData();
//   for (var i = 0; i < this.uploadedFiles.length; i++) {
//       formData.append("uploads[]", this.uploadedFiles[i], this.uploadedFiles[i].name);
//   }
//   this.http.post('/api/upload', formData)
//       .subscribe((response) => {
//           console.log('response received is ', response);
//       })

// }

  url = "./assets/gall.jpg";
  onselectFile(deepak) {
    if (deepak.target.files) {
      var render = new FileReader();
      render.readAsDataURL(deepak.target.files[0]);
      render.onload = (event: any) => {
        this.url = event.target.result;
      }
    }
  }


}
