import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ProductServiceService } from '../service/product-service.service'
import { id } from '@swimlane/ngx-datatable';
@Component({
  selector: 'app-edit-product',
  templateUrl: './edit-product.component.html',
  styleUrls: ['./edit-product.component.css']
})
export class EditProductComponent implements OnInit {
  registerForm: FormGroup;
  submitted: boolean;
  value:any;

  prodectObj={
    id:'',
    image:'',
    name:'',
    model_no:'',
    price:'',
    item:'',

  }

  constructor(private formBuilder: FormBuilder,
    private productServiceService: ProductServiceService,
    private router: Router) { }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      image:['', Validators.required], 
      Name: ['', Validators.required],
      model_no: ['', Validators.required],
      price: ['', Validators.required],
      acceptTerms: [false, Validators.requiredTrue]


    });
         if(this.productServiceService.edititem){
           const item = this.productServiceService.edititem;
          this.registerForm.patchValue({

            Name : item.name,
            model_no:item.model_no,
          price:item.price,
             
          })
         }
                
   this.addproduct(this.value)
     this.productServiceService.event.subscribe(data => {
    this.value=data;
    //  this.registerForm.controls['Name'].setValue("Deepa");
    //  this.registerForm.controls['model_no'].setValue("fdhsf");
    // this.registerForm.controls['price'].setValue(this.value.price);
          console.log()
        this.addproduct(this.productServiceService.edititem);
       // let data =this.value;
        console.log(data);

     })
     
      // this.productServiceService.getproductById(id).subscribe((data)=>console.log(data))
  }

  get f() { return this.registerForm.controls; }
  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.registerForm.invalid) {
        return;
    }

    // display form values on success
    alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.registerForm.value, null, 4));
}

    
addproduct(item) {
  console.log("=====add",item)
 alert('dd')

   console.log("see the patch value")

let data = this.registerForm.value
     this.productServiceService.updateproduct(data).subscribe((responce) => {
      console.log("Edit resonce is:",responce)
   this.router.navigate(["/List"]);
   // this.add=responce;
    console.log('add==', responce)
   // this.allproduct
 },
)


}


onReset() {
  this.submitted = false;
  this.registerForm.reset();
}


  url="./assets/gall.jpg";
  onselectFile(deepak)
  {
       if(deepak.target.files)
       {
         var render= new FileReader();
         render.readAsDataURL(deepak.target.files[0]);
         render.onload=(event:any)=>{
           this.url=event.target.result;
         }
       }
  }

}
