import { Injectable } from '@angular/core';
//import {ProductServiceService} from '../service/product-service.service'


@Injectable({
  providedIn: 'root'
})
export class ApiUrlService {
//private api:ProductServiceService
  constructor() { }
  public url = {
    getproductList: 'getproductList',
    getproductListById: '/getproductList/:id',
    deleteproductById: '/deleteproduct/:id',
    Addproduct: 'Addproduct/',
    Editproduct: 'Editproduct/',
  
  }
}
