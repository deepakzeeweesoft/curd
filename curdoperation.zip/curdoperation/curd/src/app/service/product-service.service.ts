import { Injectable, EventEmitter } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import {Observable} from 'rxjs'
import {ApiUrlService} from '../service/api-url.service'



@Injectable({
  providedIn: 'root'

})
export class ProductServiceService {
  // url ="http://localhost:3000/Addproduct/";
      public event=new EventEmitter<any>();
      public edititem:any;
  //public url = environment.apiURL;
  constructor(private httpClient:HttpClient,
    private apiUrl:ApiUrlService  ) { }


  

                 createproduct(item:any)
                 {
                    console.log("create product");
                    console.log("item is",item)
                    // return this.httpClient.post<any>("http://localhost:3000/Addproduct",item);
                    return this.httpClient.post<any>("http://localhost:3000/Addproduct",item);
                    console.log('create product is work');
                 }
                   getallproduct()
                    {
                     return this.httpClient.get("http://localhost:3000/getproductList");
                    }
                             
                    deleteproduct(item)               
                    {
                        return this.httpClient.delete("http://localhost:3000/deleteproduct/"+item.id)   
                    }
                     
                               
                    getproductById(id)               
                    {
                        return this.httpClient.get("http://localhost:3000/getproductList/"+id)   
                    }
  
                  updateproduct(data)
                  {
                    console.log("update product");
                    console.log("item is",data)
                  return this.httpClient.put("http://localhost:3000/Editproduct/"+data.id, data)

                  }

}
