import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, RouterModule } from '@angular/router';
import {ProductServiceService}  from '../service/product-service.service'

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  allproduct: any;
  value:any;

  constructor(private router: Router,
    private productServiceService:ProductServiceService ) { }

  
  ngOnInit() {
    this.getLatestProduct();

  }
  getLatestProduct()
  {
    this.productServiceService. getallproduct().subscribe((responce)=>{
        this.allproduct=responce;
        console.log(' getallproduct===',this.allproduct)
    })
  }

  deleteProduct(item)
  {
    console.log("Deleted product id is:",item.id)
    this.productServiceService.deleteproduct(item).subscribe(()=>{
      console.log("Final product is deleted");
       this.getLatestProduct()
    })
  }


  editProduct(item:any)
{
  this.productServiceService.edititem=item;
  

  //this.productServiceService.event.emit(this.value); 
  this.router.navigate(["/Edit"]);
  //  console.log("getbyid product id is:",item)
  // this.productServiceService.getproductById(item).subscribe((data)=>{ this.value = data
  //    console.log("Final product is edit:",data);
    //  this.getLatestProduct()
                     

 // })


  // console.log(item);
  
}

}
